var indexSectionsWithContent =
{
  0: "$_acdefgimnoprstu",
  1: "mopsu",
  2: "acdegimnoprs",
  3: "_cdefgimrs",
  4: "$cefit"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables"
};

