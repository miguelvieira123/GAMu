var searchData=
[
  ['student_2ephp',['student.php',['../student_8php.html',1,'']]],
  ['students_2ephp',['students.php',['../students_8php.html',1,'']]]
];
