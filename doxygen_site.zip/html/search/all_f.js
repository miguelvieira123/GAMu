var searchData=
[
  ['try',['try',['../auth_8php.html#abe4cc9788f52e49485473dc699537388',1,'try():&#160;auth.php'],['../connect_b_d_8php.html#abe4cc9788f52e49485473dc699537388',1,'try():&#160;connectBD.php'],['../registar_utilizador_8php.html#abe4cc9788f52e49485473dc699537388',1,'try():&#160;registarUtilizador.php']]]
];
