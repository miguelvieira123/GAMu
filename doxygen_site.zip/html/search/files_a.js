var searchData=
[
  ['registarutilizador_2ephp',['registarUtilizador.php',['../registar_utilizador_8php.html',1,'']]]
];
