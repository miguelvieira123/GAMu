var searchData=
[
  ['perfomances_2ephp',['perfomances.php',['../perfomances_8php.html',1,'']]],
  ['perfomances_2ephp',['perfomances.php',['../student_2perfomances_8php.html',1,'']]],
  ['perfomances_2ephp',['perfomances.php',['../prof_2perfomances_8php.html',1,'']]],
  ['professor_2ephp',['professor.php',['../classes_2professor_8php.html',1,'']]],
  ['professor_2ephp',['professor.php',['../professor_8php.html',1,'']]]
];
