var searchData=
[
  ['registarutilizador_2ephp',['registarUtilizador.php',['../registar_utilizador_8php.html',1,'']]],
  ['releaselock',['releaseLock',['../class_mutex.html#a885f879a11110e880367079fc00a4fde',1,'Mutex']]]
];
