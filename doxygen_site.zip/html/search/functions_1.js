var searchData=
[
  ['changeinfop',['changeInfoP',['../class_professor.html#a3c854411a3b8df50d900073a4d0cddb0',1,'Professor\changeInfoP()'],['../class_students.html#abfcfa4c661f424eb8a8cc8ab02d9adec',1,'Students\changeInfoP()']]],
  ['changemobile',['changeMobile',['../class_professor.html#ac12a4d779d5e7035ac47730789e1215c',1,'Professor\changeMobile()'],['../class_students.html#a3e02190efc8dd64462382cf963e07e39',1,'Students\changeMobile()']]],
  ['changenews',['changeNews',['../class_users.html#a0af913f5f8e6856bb618dbd98afaefac',1,'Users']]],
  ['checkcourseid',['checkCourseId',['../classes_2import_8php.html#ac0d4cbe032bc11edc7287f5f425d575c',1,'import.php']]],
  ['checkmatricula',['checkMatricula',['../classes_2import_8php.html#a49e599095e360d8b39394d068acb524f',1,'import.php']]],
  ['checkprofessorid',['checkProfessorId',['../classes_2import_8php.html#a026d2f122a2db82df3e05dcdd6f02e96',1,'import.php']]],
  ['checkstudent',['checkStudent',['../classes_2import_8php.html#aa3d23ace38c3cfeb3860bfbe930b8a8e',1,'import.php']]],
  ['checkstudentid',['checkStudentId',['../classes_2import_8php.html#a982b20ae93aa351b23f9b7badd4ea010',1,'import.php']]],
  ['createnews',['createNews',['../class_users.html#a27ad9012bb5c2e2e0d26d38c0f55d561',1,'Users']]],
  ['createnewuser',['createNewUser',['../class_users.html#ab8e948fbe598fd3e65992820692fcffb',1,'Users']]]
];
