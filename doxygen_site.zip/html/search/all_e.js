var searchData=
[
  ['setnewpassword',['setNewPassword',['../class_users.html#ab25a93710ce39cf7718672fff46defe1',1,'Users']]],
  ['setusercookie',['setUserCookie',['../cookie_8php.html#ad23a0caf9b7621117f7032f659d3a8d7',1,'cookie.php']]],
  ['student_2ephp',['student.php',['../student_8php.html',1,'']]],
  ['students',['Students',['../class_students.html',1,'']]],
  ['students_2ephp',['students.php',['../students_8php.html',1,'']]]
];
