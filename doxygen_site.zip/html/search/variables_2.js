var searchData=
[
  ['else',['else',['../actions_2prof_2create_news_8php.html#a0544c3fe466e421738dae463968b70ba',1,'else():&#160;createNews.php'],['../auth_8php.html#ada37e8b65cd2c8bd7d90fc44327f917c',1,'else():&#160;auth.php']]]
];
