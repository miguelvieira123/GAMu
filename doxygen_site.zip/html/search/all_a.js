var searchData=
[
  ['newaudition_2ephp',['newAudition.php',['../new_audition_8php.html',1,'']]],
  ['newuser_2ephp',['newUser.php',['../actions_2new_user_8php.html',1,'']]],
  ['newuser_2ephp',['newUser.php',['../html_2new_user_8php.html',1,'']]]
];
