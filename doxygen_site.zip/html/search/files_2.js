var searchData=
[
  ['deletenews_2ephp',['deleteNews.php',['../delete_news_8php.html',1,'']]],
  ['delsession_2ephp',['delSession.php',['../del_session_8php.html',1,'']]],
  ['deny_2ephp',['deny.php',['../deny_8php.html',1,'']]]
];
