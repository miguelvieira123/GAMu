	<ul id="menu">
		<li class="l1" onclick="setHtml('./html/student/mainPage.php','Pagina Principal')"><a href="#" title="Pagina Principal">Pagina Principal</a></li>
		<li class="l1" onclick="ShowHide('l21')"><a href="#" title="Add">Adicionar</a></li>
			<div id="l21">
				<li class="l2" onclick="setHtml('./html/newUser.php','Adicionar novo utilizador')"><a href="#" title="Novo utilizador">Novo Utilizador</a></li>
			</div>
	</ul>