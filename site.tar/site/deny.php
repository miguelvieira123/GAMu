<?php
	echo "<h3>Este utilizador não tem acesso para esta página</h3>";
?>